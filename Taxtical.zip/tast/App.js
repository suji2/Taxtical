import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import chat from './Screen/chat';
import home from './Screen/home';
import find from './components/find';
import RealEstate from './components/RealEstate';
// import RealEstate from './components/MatchingScreen';
import user from './Screen/user';
import Personal from './components/Personal';
import TabBarIcon from './components/TabBarIcon';


const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();


const homeStack = () => (
  <Stack.Navigator>
    <Stack.Screen
      name="Taxtical🚕"
      component={home}
      options={{
        headerTitleAlign: 'center', // Align the header title to the center
      }}
    />
    <Stack.Screen name="find" component={find} />
    <Stack.Screen name="RealEstate" component={RealEstate} />
  </Stack.Navigator>
);


const userStack = () => (
  <Stack.Navigator>
    <Stack.Screen
      name="Taxtical🚕"
      component={user}
      options={{
        headerTitleAlign: 'center', // Align the header title to the center
      }}
    />
    <Stack.Screen name="Personal" component={Personal} />
  </Stack.Navigator>
);


export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        tabBarOptions={{
          activeBackgroundColor: '#F0F8FF',
          activeTintColor: 'black',
          style: {
            backgroundColor: 'white',
          },
          labelPosition: 'below-icon', // Change the label position to below the icon
          tabStyle: {
            flex: 1,
          },
          indicatorStyle: {
            backgroundColor: 'black',
            height: '100%',
          },
        }}
        screenOptions={({ route }) => ({
          tabBarLabel: route.name,
          tabBarIcon: ({ focused }) => TabBarIcon(focused, route.name),
        })}
      >
        <Tab.Screen name="채팅" component={chat} />
        <Tab.Screen name="메인" component={homeStack} />
        <Tab.Screen name="정보" component={userStack} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
