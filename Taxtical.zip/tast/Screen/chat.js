import {Button, Text, View, TextInput} from 'react-native'
import {useState} from 'react'

const Home = (props)=>{

  return(
    <View>
      <Text> Taxtical  </Text>
    </View>
  )
}

export default Home