import React from 'react';
import { StyleSheet, Button, View, SafeAreaView, Text } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const Separator = () => <View style={styles.separator} />;

const Home = (props) => {
  const navigation = useNavigation();

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.buttonContainer}>
        <View style={[styles.button, styles.buttonBorder]}>
          <Button
            title="택시호출하기"
          onPress={() => navigation.navigate('RealEstate')}
            color="pink" // Set the button color to pink
          />
        </View>
        <Text style={styles.title}> </Text>
        <View style={[styles.button, styles.buttonBorder]}>
          <Button
            title="동승자 찾기"
            onPress={() => navigation.navigate('find')}
            color="pink" // Set the button color to pink
          />
        </View>
      </View>
      <View>
        <Text style={styles.title}> </Text>
        <View style={styles.fixToText}></View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F0F8FF',
  },
  title: {
    textAlign: 'center',
    marginVertical: 8,
  },
  fixToText: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  separator: {
    marginVertical: 8,
    borderBottomColor: '#737373',
    borderBottomWidth: 3,
  },
  buttonContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  button: {
    backgroundColor: 'pink',
    borderRadius: 5,
    height: 50,
    width: 150,
  },
  buttonBorder: {
    borderWidth: 2,
    borderColor: 'black',
  },
});

export default Home;