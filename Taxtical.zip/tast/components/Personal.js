import React, { useState } from 'react';
import { StyleSheet, View, SafeAreaView, Text, Button, Picker, TextInput } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { CheckBox } from 'react-native-elements';
import Modal from 'react-native-modal';

const Separator = () => <View style={styles.separator} />;

const User = (props) => {
  const navigation = useNavigation();
  const [name, setName] = useState('');
  const [gender, setGender] = useState('');
  const [year, setYear] = useState('');
  const [month, setMonth] = useState('');
  const [day, setDay] = useState('');
  const [isModalVisible, setModalVisible] = useState(false);

  const handleSave = () => {
    const dateOfBirth = `${year}.${month}.${day}`;
    console.log('Name:', name);
    console.log('Gender:', gender);
    console.log('Date of Birth:', dateOfBirth);
    setModalVisible(true);
  };

  const handleModalConfirm = () => {
    setModalVisible(false);
    // 추가 동작을 수행하거나 다른 화면으로 이동할 수 있습니다.
    // 예를 들어:
    // navigation.navigate('다음 화면');
  };

  const handleModalCancel = () => {
    setModalVisible(false);
    // 추가 동작을 수행하거나 이전 화면으로 돌아갈 수 있습니다.
    // 예를 들어:
    // navigation.goBack();
  };

  const generateYears = () => {
    const currentYear = new Date().getFullYear();
    const years = [];
    for (let year = 1950; year <= currentYear; year++) {
      years.push(year.toString());
    }
    return years;
  };

  const generateMonths = () => {
    const months = [];
    for (let month = 1; month <= 12; month++) {
      months.push(month.toString());
    }
    return months;
  };

  const generateDays = () => {
    const days = [];
    for (let day = 1; day <= 31; day++) {
      days.push(day.toString());
    }
    return days;
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.buttonContainer}>
        <View style={styles.inputContainer}>
          <Text style={styles.title}>이　　름　:　</Text>
          <TextInput
            style={styles.input}
            value={name}
            onChangeText={setName}
            placeholder="이름을 입력하시오."
            placeholderTextColor="gray"
          />
        </View>
        <Text style={styles.title}></Text>
        <View style={styles.inputContainer}>
          <Text style={styles.title}>　 성　　별　:　</Text>
          <View style={styles.genderContainer}>
            <CheckBox
              title="여자"
              checkedIcon="dot-circle-o"
              uncheckedIcon="circle-o"
              checked={gender === '여자'}
              onPress={() => setGender(gender === '여자' ? '' : '여자')}
              checkedColor="#000000"
              containerStyle={styles.checkboxContainer}
              textStyle={styles.checkboxText}
            />
            <View style={styles.genderSpacer} /> {/* Spacer view */}
            <CheckBox
              title="남자"
              checkedIcon="dot-circle-o"
              uncheckedIcon="circle-o"
              checked={gender === '남자'}
              onPress={() => setGender(gender === '남자' ? '' : '남자')}
              checkedColor="#000000"
              containerStyle={styles.checkboxContainer}
              textStyle={styles.checkboxText}
            />
          </View>
        </View>
        <Separator />
        <Text style={styles.title}></Text>
        <View style={styles.inputContainer}>
          <Text style={styles.title}>　생 년 월 일　:　</Text>
          <View style={styles.dateContainer}>
            <Picker
              style={styles.picker}
              selectedValue={year}
              onValueChange={(itemValue) => setYear(itemValue)}
            >
              <Picker.Item label="년도" value="" />
              {generateYears().map((year) => (
                <Picker.Item key={year} label={year} value={year} />
              ))}
            </Picker>
            <Picker
              style={styles.picker}
              selectedValue={month}
              onValueChange={(itemValue) => setMonth(itemValue)}
            >
              <Picker.Item label="월" value="" />
              {generateMonths().map((month) => (
                <Picker.Item key={month} label={month} value={month} />
              ))}
            </Picker>
            <Picker
              style={styles.picker}
              selectedValue={day}
              onValueChange={(itemValue) => setDay(itemValue)}
            >
              <Picker.Item label="일" value="" />
              {generateDays().map((day) => (
                <Picker.Item key={day} label={day} value={day} />
              ))}
            </Picker>
          </View>
        </View>
        <Separator />
        <Button title="저장" onPress={handleSave} />
      </View>

      <Modal isVisible={isModalVisible}>
        <View style={styles.modalContainer}>
          <Text style={styles.modalText}>정보가 수정되었습니다.</Text>
          <View style={styles.modalButtonContainer}>
            <Button title="예" onPress={() => navigation.goBack()} />
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F0F8FF',
  },
  title: {
    textAlign: 'center',
    marginVertical: 8,
  },
  separator: {
    marginVertical: 8,
    borderBottomColor: '#737373',
    borderBottomWidth: 3,
  },
  buttonContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 15,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  input: {
    flex: 1,
    height: 40,
    width: '100%',
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 8,
  },
  dateContainer: {
    flexDirection: 'row',
  },
  picker: {
    flex: 1,
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    marginHorizontal: 4,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginHorizontal: 4,
  },
  genderContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  genderSpacer: {
    width: 16, // Adjust the width as needed
  },
  checkboxContainer: {
    backgroundColor: 'transparent',
    borderWidth: 0,
    padding: 0,
  },
  checkboxText: {
    fontWeight: 'normal',
  },
  modalContainer: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 8,
  },
  modalText: {
    fontSize: 16,
    marginBottom: 16,
    textAlign: 'center',
  },
  modalButtonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
  },
});

export default User;
